import React from 'react';

const Cart = () => {
  return <h2>Cart Page (You will add cart logic using Context/Redux later)</h2>;
};

export default Cart;
