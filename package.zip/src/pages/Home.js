import React from 'react';

function Home() {
  return (
    <div>
      <h2>Welcome to My E-commerce Store!</h2>
    </div>
  );
}

export default Home;
